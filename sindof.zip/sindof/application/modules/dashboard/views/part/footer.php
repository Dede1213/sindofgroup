<!-- Main Footer -->
      <footer class="main-footer">
        <!-- To the right -->
        <div class="pull-right hidden-xs">
          .....
        </div>
        <!-- Default to the left -->
        <strong>Copyright &copy; 2018 Sistem Informasi Perusahaan.</strong>
      </footer>
